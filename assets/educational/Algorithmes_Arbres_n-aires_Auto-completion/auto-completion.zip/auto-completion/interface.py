import tkinter as tk
from tkinter import messagebox

class SuggestInterface:
    def __init__(self, root, controller):
        self.controller = controller

        # Titre de la fenêtre
        root.title("Suggestion")
        
        # Taille de la fenêtre
        width=300
        height=500
        screenwidth = root.winfo_screenwidth()
        screenheight = root.winfo_screenheight()
        alignstr = '%dx%d+%d+%d' % (width, height, (screenwidth - width) / 2, (screenheight - height) / 2)
        root.geometry(alignstr)
        root.resizable(width=False, height=False)

        # Boite d'entrée du mot à rechercher
        self.textbox_recherche=tk.Entry(root)
        self.textbox_recherche["justify"] = "center"
        self.textbox_recherche["text"] = "Rechercher"
        self.textbox_recherche.place(x=0,y=0,width=width,height=30)
        self.textbox_recherche.focus()
        self.textbox_recherche.bind('<KeyRelease>', self._textbox_recherche_key_released)
        self.textbox_recherche.bind('<Return>',     self._textbox_recherche_return)

        # Liste des résultats
        self.listbox_suggestion=tk.Listbox(root)
        self.listbox_suggestion["justify"] = "center"
        self.listbox_suggestion.place(x=0,y=30,width=300,height=height-30)

    def _textbox_recherche_key_released(self, _):
        entry_value = self.get_entry().strip()
        if entry_value == "":
            self._clear_listbox()
        else:
            self.controller.entry_updated(entry_value)

    def _textbox_recherche_return(self, _):
        selected_word = self.listbox_suggestion.get(0)
        if selected_word != "":
            messagebox.showinfo(title='Suggestion', message=selected_word)
        self._clear_listbox()
        self._clear_entry()

    def _clear_listbox(self):
        self.listbox_suggestion.delete(0, tk.END)

    def _clear_entry(self):
        self.textbox_recherche.delete(0, tk.END)

    def get_entry(self):
        return self.textbox_recherche.get()

    def set_listbox(self, words):
        self._clear_listbox()
        for word in words:
            self.listbox_suggestion.insert(tk.END, word)