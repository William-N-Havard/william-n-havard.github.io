# Auto-complétion

Programme d'auto-complétion utilisant des arbres *n*-aire, codé en Python.

## Installation

Le programme ne nécessite pas de bibliothèques spéciales pour fonctionner, seules les bibliothèques standards de Python sont requises (*tkinter*, *os*, *pprint*).

Pour utiliser le programme, il est nécessaire de télécharger un lexique. Vous pouvez en télécharger un sur le site [lexique.org](lexique.org), qui a l’avantage d’être assez complet et gratuit (la version utilisée ici est la version 3.83, mais toute autre version fait aussi bien l’affaire). Si la version diffère ou que vous choisissez un autre dictionnaire, il vous faudra changer la ligne 24 du fichier `main.py` en mettant le nom du dictionnaire que vous utilisez. Il sera également probablement nécessaire de modifier la ligne 30 pour ne récupérer que la colonne contenant les mots-formes.

## License

Le programme est distribué sous licence [Creative Commons 4.0 BY](https://creativecommons.org/licenses/by/4.0/).