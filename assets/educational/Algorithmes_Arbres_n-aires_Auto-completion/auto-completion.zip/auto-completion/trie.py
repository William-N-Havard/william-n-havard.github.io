
class Trie:

    def __init__(self, end='∅', words=[]):
        """
        Initialisation de l'objet
        (rappel en Python, le constructeur est __new__, __init__ n'est qu'un instantiateur)
        :param end: signe de fin de mot à utiliser
        :param words: liste des mots à ajouter au trie
        """
        self.root = {}
        self.end  = end

        if words:
            self.add_words(words)
            input_words = len(set(words))
            tree_words = self.num_words()
            assert input_words == tree_words, "Problème à la construction du Trie :"\
                                              "{} mots manquants !".format(abs(input_words-tree_words))

    def add_word(self, word):
        """
        Permet d'ajouter UN mot au Trie
        :param word: chaine de caractères
        :return: void
        """
        trie = self.root
        for letter in word:
            trie = trie.setdefault(letter, {})

        trie[self.end] = {}

    def add_words(self, words):
        """
        Permet d'ajouter DES mots au Trie
        :param words: liste de chaines de caractères
        :return: void
        """
        for word in words:
            self.add_word(word)

    def startswith(self, prefix):
        """
        Permet de retrouver tous les mots qui commencent avec le préfixe `prefix`
        :param prefix: chaine de caractères
        :return: set de chaines de caractères
        """
        trie = self.root
        suggestions = []

        # Pour chacune des lettres du préfixe
        for letter in prefix:
            # On essaye d'avancer dans l'arbre
            if letter in trie:
                trie = trie[letter]
            else:
                # Si on n'y arrive pas, on retourne un set vide
                return suggestions

        # Si on est là, le préfixe existe bien dans l'arbre !
        # Il ne reste plus qu'à parcourir chacune des branches et reconstruire l'ensemble des mots
        suggestions.extend(map(lambda suffix: prefix+suffix, list(self._parcours(trie))))

        # Et on retourne le tout
        return suggestions

    def num_nodes(self, trie=None):
        """
        Retourne le nombre de noeuds dans l'arbre
        :param trie: Un dictionnaire représentant le noeud à explorer
        :return: nombre de noeuds de l'arbre
        """
        trie = self.root if trie == None else trie

        n = 1
        for letter in trie:
            n += self.num_nodes(trie[letter])

        return n

    def num_words(self, trie=None):
        """
        Retourne le nombre de mots dans l'arbre
        :param trie: Un dictionnaire représentant le noeud à explorer
        :return: nombre de mots de l'arbre
        """
        trie = self.root if trie == None else trie

        n = self.end in trie
        for letter in trie:
            n += self.num_words(trie[letter])

        return int(n)

    def _parcours(self, trie):
        """
        Permet de parcourir le Trie récursivement
        :param trie: Un dictionnaire représentant le noeud à explorer
        :return: set de chaines de caractères
        """
        suffix = []

        # Est-on sur une feuille ?
        if trie == {}:
            return [""]
        

        for letter in trie:
            suffix.extend(map(lambda suffix: letter + suffix, list(self._parcours(trie[letter]))))

        return suffix
