#-*- coding: utf8 -*-

class Trie:

    def __init__(self, end='', words=None):
        """
        Initialisation de l'objet (rappel en Python, le constructeur est __new__)
        :param end: signe de fin de mot à utiliser
        :param words: liste des mots à ajouter au
        """
        self.root = {}
        self.end  = end

        if words != None:
            self.add_words(words)

    def add_word(self, word):
        """
        Permet d'ajouter UN mot au Trie
        :param word: chaine de caractères
        :return: void
        """
        trie = self.root
        for letter in word:
            trie = trie.setdefault(letter, {})
        trie[self.end] = {}

    def add_words(self, words):
        """
        Permet d'ajouter DES mots au Trie
        :param words: liste de chaines de caractères
        :return: void
        """
        for word in words:
            self.add_word(word)

    def find_closest(self, word, edit_dist=3):
        """
        Retrouve la liste des mots les plus proches du mot `word` (en termes de distance d'édition) dans le trie
        :param edit_dist: nombre d'éditions maximum
        :param word: mot à corriger
        :return: set de mots éloignés d'au plus `edit_dist` éditions du mot `word`
        """

        def _find_closest(trie, edit_dist, word):
            # Tout au long de cette fonction, j'utilise des slices (p.ex. word[2:3]) au lieu de l'indice du caractère dans
            # la chaîne (p. ex. word[2]). En effet, s'il n'y a pas de caractère à l'indice précisé, Python lèvera une excep-
            # tion ; alors que lorsque l'on passe par des slices Python ne lèvera aucune exception...
            corrections = set()

            # Tuples des lambdas (l'unpacking des tuples dans les lambdas-expressions a été supprimé en Python 3 ...):
            #   - t[0] mot reconstruit lors de la remontée
            #   - t[1] nombre d'éditions faites jusqu'à présent

            # Editions possibles
            if edit_dist > 0:
                letter = word[1:2]
                if letter in trie:
                    # insertion (l'utlisateur a ajouté une lettre en trop dans le mot)
                    # -> on s'autorise à passer au noeud de la lettre à l'indice word[1] et on ne considère pas word[0]
                    insertion = _find_closest(trie[letter], edit_dist - 1, word[2:])
                    corrections.update(map(lambda t: (letter + t[0], t[1] + 1), insertion))

                    # transposition
                    # -> on inverse la lettre à l'indice 1 et à l'indice 0 (on ne le fait que si word[1] est une clef)
                    transposition = _find_closest(trie[letter], edit_dist - 1, word[0:1] + word[2:])
                    transposition = map(lambda t: (letter + t[0], t[1] + 1), transposition)
                    corrections.update(transposition)

                for letter in trie:
                    # deletion (l'utilisateur a oublié de taper une lettre)
                    # -> on cherche la lettre manquante en s'autorisant à visiter tous les noeuds fils du noeud courant)
                    deletion = _find_closest(trie[letter], edit_dist - 1, word)
                    deletion = map(lambda t: (letter + t[0], t[1] + 1), deletion)
                    corrections.update(deletion)

                    # substitution (l'utilisateur a utilisé une lettre à la place d'un autre
                    # -> on cherche la lettre correcte en s'autorisant à visiter tous les noeuds fils du noeud courant)
                    if word[0:1] != letter:
                        substitution = _find_closest(trie[letter], edit_dist - 1, word[1:])
                        substitution = map(lambda t: (letter + t[0], t[1] + 1), substitution)
                        corrections.update(substitution)

            # On 'consomme' le mot normalement (s'il reste des lettres à consommer)
            letter, end = word[0:1], word[1:]
            if letter in trie:
                no_edition = _find_closest(trie[letter], edit_dist, end)
                corrections.update(map(lambda t: (letter + t[0], t[1]), no_edition))

            # Plus d'édition possible ... Si le noeud sur lequel on est a un lien vers un noeud marquant une fin de mot,
            # c'est qu'il s'agit de la dernière lettre d'un mot. On renvoit donc une chaine vide pour commencer à le recons-
            # truire en remontant !
            if word == '' and trie == {}:
                corrections.update(set({("", 0)})) # str: "word", int: edit_distance

            return corrections

        return _find_closest(self.root, edit_dist, word)