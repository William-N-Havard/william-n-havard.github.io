#-*- coding: utf8 -*-
import os
import tkinter as tk
import trie
import interface

class App:
    def __init__(self, words):
        self.root = tk.Tk()

        self.model = trie.Trie(words = words)
        self.view = interface.SuggestInterface(self.root, self)

    def entry_updated(self, prefixe):
        # Sort suggestions (with a maximum number of edits of 3)
        all_suggestions = sorted(self.model.find_closest(prefixe, edit_dist=3), key= lambda t: t[1])
        # Remove duplicate suggestions (same word with different number of edits)
        suggestions = [(word, min([c for w, c in all_suggestions if w == word]))
                       for word in dict.fromkeys([w for w, _ in all_suggestions])]
        self.view.set_listbox(suggestions)


    def run(self):
        self.root.mainloop()

if __name__ == '__main__':
    # On vérifie que le chemin vers le dictionnaire existe
    dict_name = 'Lexique383.tsv'
    if not os.path.exists(dict_name):
        exit("Le fichier dictionnaire est manquant !")

    # On récupère les mots du dictionaire
    with open(dict_name, encoding='utf8') as in_file:
        words = [line.strip().split('\t')[0] for line in in_file]

    # Décommentez la ligne suivante pour utiliser les mots utilisés dans l'arbre de l'article
    #words = ["abricots", "avocat", "avoine", "ananas", "banane", "baie", "kiwi", "kiwis"]

    # On lance l'application
    app = App(words)
    app.run()
